export const ROLES = {
    Employee: 'Employee',
    Manager: 'Manager',
    Admin: 'Admin'
}