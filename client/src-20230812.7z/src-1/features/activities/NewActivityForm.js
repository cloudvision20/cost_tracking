import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { useAddNewActivityMutation } from "./activitiesApiSlice"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSave } from "@fortawesome/free-solid-svg-icons"

const NewActivityForm = ({ users }) => {

    const [addNewActivity, {
        isLoading,
        isSuccess,
        isError,
        error
    }] = useAddNewActivityMutation()

    const navigate = useNavigate()

    const [name, setName] = useState('')
    const [description, setDescription] = useState('')

    // const [text, setText] = useState('')
    const [completed, setCompleted] = useState(false)
    const [userId, setUserId] = useState(users[0].id)
    const [processUnit, setProcessUnit] = useState('')
    const [processQuantity, setProcessQuantity] = useState('')
    const [durationUnit, setDurationUnit] = useState('')
    const [durationQuantity, setDurationQuantity] = useState('')


    const [typeChanged, setTypeChanged] = useState('')
    const [detailsChanged, setDetailsChanged] = useState('')
    const [jobChanged, setJobChanged] = useState('')
    const [costTypeChanged, setCostTypeChanged] = useState('')
    const [uomChanged, setUomChanged] = useState('')
    const [rateChanged, setRateChanged] = useState('')
    const [qtyAssignChanged, setQtyAssignChanged] = useState('')
    const [remarksChanged, setRemarksChanged] = useState('')

    useEffect(() => {
        if (isSuccess) {
            setName('')
            setDescription('')
            //setText('')
            setCompleted(false)
            setUserId('')
            setProcessUnit('')
            setProcessQuantity('')
            setDurationUnit('')
            setDurationQuantity('')
            setTypeChanged('')
            setDetailsChanged('')
            setJobChanged('')
            setCostTypeChanged('')
            setUomChanged('')
            setRateChanged('')
            setQtyAssignChanged('')
            setRemarksChanged('')
            navigate('/dash/activities')
        }
    }, [isSuccess, navigate])

    const onNameChanged = e => setName(e.target.value)
    const onDescriptionChanged = e => setDescription(e.target.value)

    //const onTextChanged = e => setText(e.target.value)
    const onCompletedChanged = e => setCompleted(e.target.value ? true : false)
    const onUserIdChanged = e => setUserId(e.target.value)
    const onProcessUnitChanged = e => setProcessUnit(e.target.value)
    const onProcessQuantityChanged = e => setProcessQuantity(e.target.value)
    const onDurationUnitChanged = e => setDurationUnit(e.target.value)
    const onDurationQuantityChanged = e => setDurationQuantity(e.target.value)
    const canSave = [userId].every(Boolean) && !isLoading

    const onTypeChanged = e => setTypeChanged(e.target.value)
    const onDetailsChanged = e => setDetailsChanged(e.target.value)
    const onJobChanged = e => setJobChanged(e.target.value)
    const onCostTypeChanged = e => setCostTypeChanged(e.target.value)
    const onUomChanged = e => setUomChanged(e.target.value)
    const onRateChanged = e => setRateChanged(e.target.value)
    const onQtyAssignChanged = e => setQtyAssignChanged(e.target.value)
    const onRemarksChanged = e => setRemarksChanged(e.target.value)

    const onSaveActivityClicked = async (e) => {
        e.preventDefault()
        if (canSave) {
            await addNewActivity({ user: userId, name, description, completed })
        }
    }

    const options = users.map(user => {
        return (
            <option
                key={user.id}
                value={user.id}
            > {user.username}</option >
        )
    })

    const errClass = isError ? "errmsg" : "offscreen"
    // const validTitleClass = !title ? "form__input--incomplete" : ''
    // const validTextClass = !text ? "form__input--incomplete" : ''
    // const onEditChanged = (e) => {
    //     console.log(e.target.innerText)

    // }
    const onClickDiv = (e) => {
        const innertxt = e.target.innerText

        let eTarget = e
        console.log(innertxt)
        e.target.innerHTML = `<input type='text' id='txtt' onChange={this.parentNode.innerText=this.value} value='${innertxt}' /input>`

    }


    //     const tableContent = `<tr className="">
    //     <td className=""></td>
    //     <td className=""></td>
    //     <td className=""></td>
    //     <td className=""></td>
    //     <td className=""></td>
    //     <td className=""></td>
    //     <td className=""></td>
    //     <td className=""></td>
    // </tr>
    // `
    const content = (
        <>
            <p className={errClass}>{error?.data?.message}</p>

            <form onSubmit={onSaveActivityClicked}>
                <div className="panel">
                    <h2>New Activity</h2>
                    <div className="form-group form__action-buttons">
                        <button
                            className="btn btn-primary"
                            title="Save"
                            onClick={onSaveActivityClicked}
                            disabled={!canSave}
                        >
                            <FontAwesomeIcon icon={faSave} />
                        </button>
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-2">Name:</div>
                    <div className="col-sm-6">
                        <input
                            className="form-control"
                            id="activity-name"
                            name="Name"
                            type="text"
                            placeholder="Name"
                            autoComplete="off"
                            value={name}
                            onChange={onNameChanged}
                        />
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-2">Description:</div>
                    <div className="col-sm-6">
                        <textarea
                            className="form-control"
                            id="activity-description"
                            name="description"
                            placeholder="Description"
                            rows="4"
                            value={description}
                            onChange={onDescriptionChanged}
                        />
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-2">Activity Process:</div>
                    <div className="col-sm-3">
                        <input
                            className="form-control"
                            id="process-unit"
                            name="process-unit"
                            type="text"
                            placeholder="Process Unit"
                            autoComplete="off"
                            value={processUnit}
                            onChange={onProcessUnitChanged}
                        />
                    </div>
                    <div className="col-sm-3">
                        <input
                            className="form-control"
                            id="process-quantity"
                            name="process-quantity"
                            type="text"
                            placeholder="Process Quantity"
                            autoComplete="off"
                            value={processQuantity}
                            onChange={onProcessQuantityChanged}
                        />
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-2">Activity Duration:</div>
                    <div className="col-sm-3">
                        <input
                            className="form-control"
                            id="duration-unit"
                            name="duration-unit"
                            type="text"
                            placeholder="Duration Unit"
                            autoComplete="off"
                            value={durationUnit}
                            onChange={onDurationUnitChanged}
                        />
                    </div>
                    <div className="col-sm-3">
                        <input
                            className="form-control"
                            id="duration-quantity"
                            name="duration-quantity"
                            type="text"
                            placeholder="Duration Quantity"
                            autoComplete="off"
                            value={durationQuantity}
                            onChange={onDurationQuantityChanged}
                        />
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-2" id="divt"
                        onClick={(e) => onClickDiv(e)}
                    >Resources:</div>
                    <div className="table-responsive-sm">
                        {/* <textarea
                            className="form-control"
                            id="text"
                            name="text"
                            rows="4"
                            value={text}
                            onChange={onTextChanged}

                        /> */}
                        <table className="table table-sm table-bordered table-condensed table-striped table-hover">
                            <thead className="">
                                <tr>
                                    <th scope="" className="col-sm">type</th>
                                    <th scope="col" className="col-sm-2">details</th>
                                    <th scope="col" className="col-sm">job</th>
                                    <th scope="col" className="col-sm">costType</th>
                                    <th scope="col" className="col-sm">uom</th>
                                    <th scope="col" className="col-sm">rate</th>
                                    <th scope="col" className="col-sm">Quantity Assign</th>
                                    <th scope="col" className="col-sm-2">remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="">
                                    <td className=""><input type="text" id="type" onChange={onTypeChanged} /></td>
                                    <td className=""><input type="text" id="details" onChange={onDetailsChanged} /></td>
                                    <td className=""><input type="text" id="job" onChange={onJobChanged} /></td>
                                    <td className=""><input type="text" id="costType" onChange={onCostTypeChanged} /></td>
                                    <td className=""><input type="text" id="uom" onChange={onUomChanged} /></td>
                                    <td className=""><input type="text" id="rate" onChange={onRateChanged} /></td>
                                    <td className=""><input type="text" id="qtyAssign" onChange={onQtyAssignChanged} /></td>
                                    <td className=""><input type="text" id="remarks" onChange={onRemarksChanged} /></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="panel panel-info">

                    <div className="form-group row">
                        <div className="col-sm-2"> WORK COMPLETE:</div>
                        <div className="col-sm-10">
                            <div className="form-check">
                                <input
                                    className="form-check-input"
                                    id="activity-completed"
                                    name="completed"
                                    type="checkbox"
                                    checked={completed}
                                    onChange={onCompletedChanged}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="form-group row">
                        <div className="col-sm-2"> ASSIGNED TO:</div>
                        <div className="col-sm-2">
                            <select
                                id="username"
                                name="username"
                                className="form-control"
                                value={userId}
                                onChange={onUserIdChanged}
                            >
                                {options}
                            </select>
                        </div>
                    </div>
                </div>
            </form>

        </>
    )


    return content
}

export default NewActivityForm